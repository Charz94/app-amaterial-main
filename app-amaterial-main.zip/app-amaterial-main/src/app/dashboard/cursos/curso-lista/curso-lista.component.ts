import { Component } from '@angular/core';

@Component({
  selector: 'app-curso-lista',
  standalone: true,
  imports: [],
  templateUrl: './curso-lista.component.html',
  styleUrl: './curso-lista.component.css'
})
export class CursoListaComponent {

}
