import { Component } from '@angular/core';

@Component({
  selector: 'app-estado-detalle',
  standalone: true,
  imports: [],
  templateUrl: './estado-detalle.component.html',
  styleUrl: './estado-detalle.component.css'
})
export class EstadoDetalleComponent {

}
