import { Component } from '@angular/core';

@Component({
  selector: 'app-estado-lista',
  standalone: true,
  imports: [],
  templateUrl: './estado-lista.component.html',
  styleUrl: './estado-lista.component.css'
})
export class EstadoListaComponent {

}
