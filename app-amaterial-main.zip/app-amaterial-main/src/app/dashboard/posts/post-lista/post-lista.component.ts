import { Component } from '@angular/core';

@Component({
  selector: 'app-post-lista',
  standalone: true,
  imports: [],
  templateUrl: './post-lista.component.html',
  styleUrl: './post-lista.component.css'
})
export class PostListaComponent {

}
