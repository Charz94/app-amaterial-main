import { Component } from '@angular/core';

@Component({
  selector: 'app-post-detalle',
  standalone: true,
  imports: [],
  templateUrl: './post-detalle.component.html',
  styleUrl: './post-detalle.component.css'
})
export class PostDetalleComponent {

}
